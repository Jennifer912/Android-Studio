package com.example.tutorial

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button

class MainActivity : AppCompatActivity() {
    var b1 : Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        fun goToBrowser(view: View){
            b1 = findViewById<Button>(R.id.myButton)
            b1!!.setOnClickListener(View.OnClickListener{
                val i = Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("http://www.qa.com")
                )
                startActivity(i)
            })

        }
    }
}