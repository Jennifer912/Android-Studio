package com.example.myapplication_jen

import android.app.ProgressDialog.show
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import com.google.android.material.snackbar.Snackbar


class MainActivity : AppCompatActivity() {
    var TAG = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var textEdit = findViewById<TextView>(R.id.randomizedText)

        var randomizeBtn = findViewById<Button>(R.id.randomizedBtn)

        randomizeBtn.setOnClickListener {
            textEdit.text = listbase()
            Log.d(TAG, "Message goes here")
            Toast.makeText(this, "Updating text", Toast.LENGTH_SHORT).show()
            findViewById<Button>(R.id.fab).setOnClickListener { view ->
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                    .setAction("Action", null).show()
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main, menu)
        return true
    }
}
//        just follow with ed for now please !
        //var button = findViewById<Button>(R.id.button)
       /*button.setOnClickListener {
            Log.d(TAG, "hi im over here")
            val toast = Toast.makeText(this, "Look im toast", Toast.LENGTH_LONG)
            toast.show()
        }
    }
}*/