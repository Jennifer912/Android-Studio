package com.example.myapplication_jen

import kotlin.random.Random

var joinedList = mutableListOf<String>()

fun listbase(): String {
    var maleNames = listOf("Luke", "Enrico", "Ali", "Hamza")

    var femaleNames = listOf("lucy", "Jennifer", "Sumaya", "Mai")

    joinedList.addAll(maleNames)
    joinedList.addAll(femaleNames)

    val random = Random
    var r = random.nextInt(joinedList.count())

    return joinedList[r]
}