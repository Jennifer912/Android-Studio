package com.example.myapplication

import android.os.Bundle
import android.util.Log
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    var TAG = "Debug Message:"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var textEdit = findViewById<TextView>(R.id.randomizeText )

        var randomizeBtn = findViewById<Button>(R.id. randomizeBtn)

        randomizeBtn.setOnClickListener {
            textEdit.text = listbase()
            Log.d(TAG, "$joinedList")
            Toast.makeText(this, "Updating text", Toast.LENGTH_SHORT).show()

        }

    }

    fun onCreateOptionMenu(menu : Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }


}